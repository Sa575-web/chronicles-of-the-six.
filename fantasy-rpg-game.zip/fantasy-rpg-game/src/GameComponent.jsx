import React, { useEffect, useRef } from "react";
import Phaser from "phaser";

const characters = [
  { name: "Juweriya", role: "Rogue", skill: "Stealth" },
  { name: "Sabrin", role: "Healer", skill: "Protection" },
  { name: "Salman", role: "Warrior", skill: "Heavy Attack" },
  { name: "Abubakar", role: "Archer", skill: "Trap Master" },
  { name: "Abdullahi", role: "Mage", skill: "Elemental Magic" },
  { name: "Hoyoo", role: "Elder", skill: "Wisdom Boost" },
];

const quests = [
  { id: 1, title: "Find the Lost Amulet", description: "Retrieve the ancient amulet from the Mystic Forest." },
  { id: 2, title: "Defeat the Bandit Leader", description: "Eliminate the threat in Shadow Mountains." },
  { id: 3, title: "Solve the Puzzle of Ruins", description: "Unlock the secret in the Ancient Ruins." },
];

class MainScene extends Phaser.Scene {
  constructor() {
    super("MainScene");
    this.questLog = [];
  }

  preload() {
    this.load.image("player", "https://labs.phaser.io/assets/sprites/phaser-dude.png");
    this.load.image("enemy", "https://labs.phaser.io/assets/sprites/space-baddie.png");
  }

  create() {
    this.player = this.physics.add.sprite(100, 100, "player");
    this.player.setCollideWorldBounds(true);

    this.enemy = this.physics.add.sprite(300, 100, "enemy");
    this.enemy.setCollideWorldBounds(true);
    this.enemy.health = 3;

    this.cursors = this.input.keyboard.createCursorKeys();
    this.attackKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);

    this.questText = this.add.text(10, 10, "Quest: " + quests[0].title, { font: "16px Arial", fill: "#ffffff" });

    this.physics.add.overlap(this.player, this.enemy, this.handleCombat, null, this);
  }

  update() {
    this.player.setVelocity(0);
    if (this.cursors.left.isDown) this.player.setVelocityX(-160);
    if (this.cursors.right.isDown) this.player.setVelocityX(160);
    if (this.cursors.up.isDown) this.player.setVelocityY(-160);
    if (this.cursors.down.isDown) this.player.setVelocityY(160);

    if (Phaser.Input.Keyboard.JustDown(this.attackKey)) {
      this.attackEnemy();
    }
  }

  attackEnemy() {
    if (Phaser.Math.Distance.BetweenPoints(this.player, this.enemy) < 50) {
      this.enemy.health -= 1;
      this.questText.setText("Enemy hit! Health: " + this.enemy.health);

      if (this.enemy.health <= 0) {
        this.enemy.destroy();
        this.questText.setText("Quest Complete: " + quests[1].title);
        this.questLog.push(quests[1]);
      }
    }
  }

  handleCombat(player, enemy) {
    this.questText.setText("You are in combat! Press SPACE to attack.");
  }
}

const GameComponent = () => {
  const gameRef = useRef(null);

  useEffect(() => {
    if (!gameRef.current) {
      gameRef.current = new Phaser.Game({
        type: Phaser.AUTO,
        width: 800,
        height: 600,
        physics: {
          default: "arcade",
          arcade: {
            gravity: { y: 0 },
            debug: false,
          },
        },
        scene: [MainScene],
        parent: "phaser-container",
      });
    }
  }, []);

  return <div id="phaser-container" className="w-full h-screen" />;
};

export default GameComponent;
