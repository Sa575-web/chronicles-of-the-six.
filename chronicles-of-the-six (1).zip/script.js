const quests = [
  { title: "Find the Lost Amulet" },
  { title: "Defeat the Bandit Leader" },
];

class TitleScene extends Phaser.Scene {
  constructor() {
    super("TitleScene");
  }

  preload() {
    this.load.image("titleScreen", "title.png");
  }

  create() {
    this.add.image(400, 300, "titleScreen").setDisplaySize(800, 600);
    const startText = this.add.text(400, 540, "Click to Start", {
      font: "28px 'Segoe UI'",
      fill: "#fff",
      backgroundColor: "#0008",
      padding: { x: 16, y: 8 },
    }).setOrigin(0.5).setInteractive();

    startText.on("pointerdown", () => this.scene.start("MainScene"));
  }
}

class MainScene extends Phaser.Scene {
  constructor() {
    super("MainScene");
  }

  preload() {
    this.load.image("player", "https://labs.phaser.io/assets/sprites/phaser-dude.png");
    this.load.image("enemy", "https://labs.phaser.io/assets/sprites/space-baddie.png");
    this.load.image("background", "https://labs.phaser.io/assets/skies/space3.png");
  }

  create() {
    this.add.image(400, 300, "background");
    this.player = this.physics.add.sprite(100, 100, "player").setScale(1.2);
    this.enemy = this.physics.add.sprite(300, 100, "enemy").setScale(1.2);
    this.enemy.health = 3;

    this.cursors = this.input.keyboard.createCursorKeys();
    this.attackKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);

    this.questText = this.add.text(20, 20, "Quest: " + quests[0].title, {
      font: "18px Arial",
      fill: "#0ff",
      backgroundColor: "#000",
      padding: { x: 10, y: 5 },
    });

    this.physics.add.overlap(this.player, this.enemy, this.handleCombat, null, this);
  }

  update() {
    this.player.setVelocity(0);
    if (this.cursors.left.isDown) this.player.setVelocityX(-160);
    if (this.cursors.right.isDown) this.player.setVelocityX(160);
    if (this.cursors.up.isDown) this.player.setVelocityY(-160);
    if (this.cursors.down.isDown) this.player.setVelocityY(160);
    if (Phaser.Input.Keyboard.JustDown(this.attackKey)) this.attackEnemy();
  }

  attackEnemy() {
    if (Phaser.Math.Distance.Between(this.player.x, this.player.y, this.enemy.x, this.enemy.y) < 50) {
      this.enemy.health -= 1;
      this.questText.setText("Enemy hit! Health: " + this.enemy.health);
      if (this.enemy.health <= 0) {
        this.enemy.destroy();
        this.questText.setText("✔ Quest Complete: " + quests[1].title);
      }
    }
  }

  handleCombat() {
    this.questText.setText("⚔ In combat! Press SPACE to attack.");
  }
}

new Phaser.Game({
  type: Phaser.AUTO,
  width: 800,
  height: 600,
  parent: "phaser-container",
  physics: { default: "arcade", arcade: { gravity: { y: 0 } } },
  scene: [TitleScene, MainScene],
});
